# 🎨 Hackathon Landing Page - Visual Guide

## Page Structure Overview

```
┌─────────────────────────────────────────────────────────┐
│  🔝 NAVIGATION (Fixed)                                  │
│  SNS DT-AI-Hack | Groq | Login Button                   │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🎯 HERO SECTION                                         │
│  "Real-world Problems Solved with Real-time Inference"  │
│  ┌──────────┬──────────┬──────────┬──────────┐         │
│  │  $18K+   │   500+   │    6     │   ⚡Fast │         │
│  │  Prizes  │ People   │  Tracks  │  Speed   │         │
│  └──────────┴──────────┴──────────┴──────────┘         │
│  [Start Building] [View Resources]                      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  💡 WHAT IS GROQ PLATFORM? (NEW!)                       │
│  ┌───────────────────────────────────────────────┐     │
│  │ 🔧 Company Background & LPU Engine            │     │
│  │ ☁️  GroqCloud  │  🖥️  GroqRack                │     │
│  └───────────────────────────────────────────────┘     │
│  🎯 HACKATHON GOAL (Red Banner)                        │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📋 OVERVIEW SECTION                                     │
│  ┌───────────────────────────────────────────────┐     │
│  │ THE CHALLENGE                                  │     │
│  │ ✓ At least 2 agents                           │     │
│  │ ✓ Real-time performance                       │     │
│  │ ✓ (Optional) MCP integration                  │     │
│  │ ✓ Multi-modal intelligence                    │     │
│  │ ✓ Meaningful impact                           │     │
│  └───────────────────────────────────────────────┘     │
│  🤖 Beyond Chatbots  │  💡 Real-World Impact            │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🎯 CHALLENGE REQUIREMENTS                               │
│  ┌────┬────┬────┬────┬────┬────┐                      │
│  │ 🤖 │ ⚡ │ 🔌 │ 🎯 │ 💡 │ 🚀 │                      │
│  │Multi│Real│MCP │Multi│Use │Etc │                      │
│  │Agent│Time│Int │Modal│Case│    │                      │
│  └────┴────┴────┴────┴────┴────┘                      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📚 DEVELOPER RESOURCES                                  │
│                                                          │
│  🚀 QUICK START GUIDE (NEW!)                            │
│  ┌───────────────────────────────────────────────┐     │
│  │ ① Create Account                               │     │
│  │ ② Generate API Key (millions of free tokens)  │     │
│  │ ③ Choose Models                                │     │
│  │ ④ Test in Playground                           │     │
│  │ ⑤ Make First API Call                          │     │
│  └───────────────────────────────────────────────┘     │
│  [Console] [Models] [Playground] [Docs] [API Keys]     │
│                                                          │
│  💰 PRICING TIERS (NEW!)                                │
│  ┌─────────────────────┬─────────────────────┐         │
│  │ 🎁 FREE TIER        │ 🚀 DEVELOPER TIER   │         │
│  │ • Millions tokens   │ ⭐ HACKATHON SPECIAL │         │
│  │ • No credit card    │ • $10 in credits    │         │
│  │ • Perfect testing   │ • Hundreds of       │         │
│  │                     │   millions of tokens│         │
│  │                     │ ┌─────────────────┐ │         │
│  │                     │ │AIMGROQAUG2025   │ │         │
│  │                     │ │      [Copy]     │ │         │
│  │                     │ └─────────────────┘ │         │
│  └─────────────────────┴─────────────────────┘         │
│                                                          │
│  💰 HOW TO GET MORE CREDITS? (NEW!)                     │
│  ① Create account → ② Read docs → ③ Start building     │
│  ④ Join community forum                                 │
│                                                          │
│  💻 CODE EXAMPLES                                        │
│  [Docs] [GitHub] [Cookbook] [Desktop] [CLI] [LLMs.txt] │
│                                                          │
│  👥 COMMUNITY & SUPPORT                                  │
│  ┌───────────────────────────────────────────────┐     │
│  │ 🎧 HACKATHON SUPPORT (NEW!)                   │     │
│  │ DevRel team provides real-time assistance     │     │
│  └───────────────────────────────────────────────┘     │
│  [Forum] [@GroqInc] [@ozenhati] [@benankdev] [@yawnxyz]│
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  💬 JOIN TELEGRAM COMMUNITY                              │
│  [Join Telegram Group]                                   │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  ⭐ WHY THIS MATTERS (NEW!)                              │
│  ┌──────────┬──────────┬──────────┐                    │
│  │ ⚡ Groq  │ 🔌 MCP   │ 🚀 Your  │                    │
│  │ Real-time│ Seamless │Opportun  │                    │
│  │ Inference│Integration│   ity   │                    │
│  │Millisecs │Production│Next-Gen  │                    │
│  └──────────┴──────────┴──────────┘                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🎉 WHY WE'RE EXCITED                                    │
│  ⚡ Lightning-Fast │ 🔌 MCP-Powered │ 🏗️ Production      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🎯 CHALLENGE TRACKS (6 Tracks)                          │
│  🏥 Healthcare │ 💰 Financial │ 📦 Supply Chain          │
│  🎧 Customer   │ 🌱 Sustainability │ 🚀 Cross-Domain     │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📅 EVENT TIMELINE                                       │
│  Aug 26 → Sep 1 → Oct 6 (Submission) → Results         │
│  [45 Days Development] [45 Days Judging] [Oct 6 Results]│
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🏗️ SAMPLE ARCHITECTURE                                  │
│  Agent Ensemble: 5 Agents                               │
│  ┌─────────────────────────────────────┐               │
│  │ 🎤 Intake → 👁️ Vision → 🏷️ Classify │               │
│  │        ↓                              │               │
│  │      🔌 Integration ← 👑 Orchestrator│               │
│  └─────────────────────────────────────┘               │
│                                                          │
│  FLOW EXAMPLE (NEW!)                                     │
│  ① Voice input: "Process invoices..."                   │
│  ② Vision extracts data                                 │
│  ③ Validation via MCP DB                                │
│  ④ MCP updates accounting                               │
│  ⑤ Voice feedback confirms                              │
│                                                          │
│  ⚡ Sub-500ms Response Time                              │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  ⚖️ JUDGING CRITERIA                                     │
│  35% Technical │ 35% Impact │ 30% Innovation            │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📝 SUBMISSION GUIDELINES                                │
│  ① Executive Summary                                     │
│  ② System Architecture                                   │
│  ③ Technical Implementation                              │
│  ④ Live Demo                                             │
│  ⑤ Performance & Impact                                  │
│  ⑥ Setup & Deployment                                    │
│  [Submit Project] [Need Help?] [Register Now]          │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  🔗 FOOTER                                               │
│  SNS DT-AI-Hack | Quick Links | Connect                    │
│  © 2025 SNS DT-AI-Hack. Powered by Groq.                   │
└─────────────────────────────────────────────────────────┘
```

---

## 🎨 Color Scheme

### Primary Colors:
- **Red:** `#DC2626` - Primary brand color
- **Dark Background:** `#0F0F0F` - Main background
- **Gray Background:** `#1A1A1A` - Section alternation

### Accent Colors:
- **Blue:** Healthcare, Community, MCP
- **Green:** Success, Completed, Validation
- **Purple:** Vision, Innovation
- **Yellow:** Speed, Lightning, Performance
- **Red:** Primary CTAs, Highlights

---

## 🆕 New Visual Elements

### 1. Promo Code Card
```
┌────────────────────────────────────┐
│ 🚀 DEVELOPER TIER                  │
│ ⭐ HACKATHON SPECIAL (badge)       │
│                                    │
│ 🎁 $10 in API credits              │
│ (hundreds of millions of tokens)   │
│                                    │
│ ┌──────────────────────────────┐  │
│ │ AIMGROQAUG2025      [📋 Copy] │  │
│ └──────────────────────────────┘  │
└────────────────────────────────────┘
```

### 2. Step-by-Step Guide
```
┌─────────────────────────────────────┐
│ ① Create Account                    │
│   Visit console.groq.com            │
│                                     │
│ ② Generate API Key                  │
│   Millions of free tokens!          │
│                                     │
│ ③ Choose Models                     │
│   Browse at docs/models             │
└─────────────────────────────────────┘
```

### 3. Why This Matters Cards
```
┌─────────┬─────────┬─────────┐
│ ⚡ Groq │ 🔌 MCP  │ 🚀 You  │
│ Real-   │ Seamless│ Next-   │
│ time    │ Integr. │ Gen     │
│  (Red)  │ (Blue)  │(Purple) │
└─────────┴─────────┴─────────┘
```

### 4. Flow Example
```
┌────────────────────────────────┐
│ ① Voice input                  │
│ ② Vision extracts              │
│ ③ Validation via MCP           │
│ ④ MCP updates system           │
│ ⑤ Voice feedback               │
└────────────────────────────────┘
```

---

## 📱 Responsive Behavior

### Desktop (1024px+)
- 3 columns for resource cards
- 3 columns for challenge tracks
- Side-by-side pricing cards
- Full navigation visible

### Tablet (768px - 1023px)
- 2 columns for most grids
- Stacked pricing cards
- Condensed navigation

### Mobile (< 768px)
- Single column layout
- Full-width cards
- Hamburger menu (if implemented)
- Touch-optimized buttons

---

## ✨ Interactive Features

### Hover Effects:
- Cards lift up (`transform: translateY(-8px)`)
- Border color changes to Red
- External link icons highlight
- Button scales slightly

### Scroll Animations:
- Sections fade in from bottom
- Staggered card animations
- Timeline progress indicators
- Stats counter animations

### Click Actions:
- Smooth scroll to sections
- Copy promo code to clipboard
- External links open in new tabs
- Ripple effect on buttons

---

## 🔗 Navigation Flow

```
Hero → About Groq → Overview → Challenge → Resources
  ↓                                          ↓
Timeline ← Tracks ← Community ← Pricing ← Quick Start
  ↓
Architecture → Why This Matters → Why Excited
  ↓
Judging → Submission → Footer
```

---

## 📊 Key Metrics Displayed

- **$18K+** - Total prizes and credits
- **500+** - Participants expected
- **6** - Challenge tracks
- **⚡ Fast** - Inference speed
- **45 Days** - Development time
- **Sub-500ms** - Response time target
- **35%/35%/30%** - Judging criteria weights

---

## 🎯 Call-to-Action Hierarchy

### Primary CTAs (Red):
1. "Start Building Now" (Hero)
2. "Submit Your Project" (Submission)
3. "Register Now" (Submission)

### Secondary CTAs (Gray):
1. "View Resources" (Hero)
2. "Need help with submission?" (Submission)

### Tertiary CTAs (Links):
1. "Join Telegram Group" (Community)
2. All resource cards
3. Social media links

---

## 🎨 Typography Hierarchy

```
Display Font (Space Grotesk):
- H1: 5xl (48px) - 7xl (72px) - Hero
- H2: 4xl (36px) - 5xl (48px) - Section Titles
- H3: 2xl (24px) - 3xl (30px) - Subsections

Body Font (Inter):
- XL (20px) - 2XL (24px) - Important text
- LG (18px) - Regular body
- Base (16px) - Standard text
- SM (14px) - Card descriptions
- XS (12px) - Fine print
```

---

This landing page is now **complete** with all information and ready to launch! 🚀
